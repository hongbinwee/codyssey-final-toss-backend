# Product RAG — BGE-M3 자료

현재 실행 상태를 기준으로 RAG 관련 문서·데이터 구조·모델 비교·평가·API를 정리한 브랜치입니다.

- **[BGE-M3 전체 자료 목차](docs/rag/README.md)**
- [현재 구성과 메서드 흐름](docs/rag/current-system.md)
- [전체 보고서 PDF](artifacts/rag-bge-m3-full-documentation-2026-10-20.pdf)
- [현재 요청 JSON Schema](docs/rag/evidence/current-bge-request.schema.json)
- [현재 실행 BGE 소스 출처](docs/rag/reference-code/bge-m3/source-metadata.json)
- [팀 Git 협업 기준](docs/team-git-workflow.md)

2026-10-20 18:25 KST 확인: 5432/toss_rag, test_items2 전체 114,106개 BGE-M3 1,024차원 벡터 ready, API에서 BGE 사용.

이 문서 브랜치의 기존 src는 24a1051 기반 코드입니다. 현재 실행 BGE 소스는 docs/rag/reference-code/bge-m3에 읽기용 사본으로 보관했습니다. 문서 갱신이 애플리케이션 코드를 교체한 것은 아닙니다.

현재 BGE API 0.2.0과 이전 추천 품질 API 0.3.0의 기능 차이는 API 연동 문서에 기록했습니다. 원문 아카이브의 상태 표현은 작성 당시 기준입니다.

이번 자료 갱신은 로컬 저장 상태이며 새 커밋·푸시·main 반영을 수행하지 않았습니다.
