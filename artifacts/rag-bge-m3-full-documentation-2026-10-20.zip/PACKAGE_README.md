# BGE-M3 RAG 전체 자료 — 2026-10-20 갱신

시작: docs/rag/README.md
통합 보고서: artifacts/rag-bge-m3-full-documentation-2026-10-20.pdf (31쪽)
전체 원문 목록: docs/rag/document-catalog.md

운영 기준: 2026-10-20 18:25 KST 직접 확인.
모델: BAAI/bge-m3 / dense 1,024차원 / 입력 128토큰.
검색: BM25 + BGE-M3 → 상품 RRF(k=60).
DB: 5432/toss_rag.
데이터: test_items2 1,500상품 / 1,917옵션 / 46,100리뷰.
청크: 기존 v2 96토큰 / 전체 114,106개 BGE 벡터 ready.

원문 자료 239개, 발견 위치/버전 300건.
현재 실행 소스는 docs/rag/reference-code/bge-m3에 읽기용으로 포함했습니다.
이 ZIP은 전체 서비스 설치/배포 패키지나 BGE 원시 벡터 덤프가 아닙니다.
원본 데이터/모델 가중치/실제 .env/인증정보는 포함하지 않습니다.
기존 데이터 ZIP의 벡터는 MiniLM 시점 자료이며 최신 BGE 덤프가 아닙니다.

현재 BGE API는 0.2.0입니다. 이전 0.3.0의 profile/product_type/in_stock 및
가격·재고 검증 기능이 모두 통합된 것으로 간주하지 마세요. 상세 차이는 integration-and-gaps.md에 있습니다.
전체 범주 BGE 전환이 전체 추천 정확도 측정을 뜻하지는 않습니다.
과거 원문/14:47 상태는 당시 스냅샷으로 보존했습니다.

Backend 브랜치: feature/rag-documentation-index.
이번 자료 갱신은 로컬 저장이며 새 커밋/푸시/main 반영을 하지 않았습니다.
