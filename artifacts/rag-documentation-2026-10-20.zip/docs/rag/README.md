# RAG 문서 통합 목차

기준일: **2026-10-20**. 현재 상태는 **14:47 KST**의 컨테이너·DB 읽기 전용 확인을 기준으로 한다.

## 먼저 읽을 문서

| 알고 싶은 내용 | 정리 문서 |
|---|---|
| 지금 무엇이 실행되는지, 검색 흐름과 메서드, LangChain 위치 | **[현재 RAG 구성](current-system.md)** |
| 어떤 데이터인지, 원본·옵션·리뷰·청크·프로필 관계 | **[데이터셋과 저장 구조](datasets-and-storage.md)** |
| 무엇을 어떻게 청킹했는지, 96토큰 이유, 모델·차원·버전 | **[청킹과 임베딩](chunking-and-embeddings.md)** |
| MiniLM/E5/BGE/Qwen 비교, 비용, 과거/현재 평가의 차이 | **[모델 비교와 RAG 평가 기록](model-comparisons-and-evaluation.md)** |
| search_rag/search_products, API 계약, Agent 프롬프트, 남은 작업 | **[API·Agent 연동과 남은 과제](integration-and-gaps.md)** |
| 모든 원문·PDF·JSON·계약·설계·과거 평가 찾기 | **[전체 문서 목록](document-catalog.md)** |
| 원래 경로·브랜치·Git blob·중복본·SHA-256 확인 | [기계 판독용 원문 manifest](source-manifest.json) |
| 실제 실행 설정·DB 프로필·수량의 확인 증거 | [실행 상태 JSON](evidence/runtime-snapshot-2026-10-20.json) |

## 현재 상태 한눈에 보기

| 항목 | 확인 결과 |
|---|---|
| DB | **5432/toss_rag** — 검색. 원본/가격/재고는 같은 5432의 `toss.test_items2` |
| 기본 데이터 | **test_items2**, beauty/fashion/food/living |
| 규모 | **상품 1,500 · 옵션 1,917 · 리뷰 46,100 · 청크 114,106** |
| 리뷰 출처 | REAL 41,523 / SYNTHETIC 4,577, 내부 개발 CANDIDATE |
| 현재 임베딩 | **다국어 MiniLM-L12-v2, 384차원** |
| 기존 청킹 | **v2, 최대 96토큰, overlap 없음** |
| 청커 코드 | v3가 배포 소스에 있지만 기존 색인은 v2 유지 |
| 검색 | 상품 유형·옵션 가격/재고 확인 → BM25/벡터 → 상품 RRF·정체성 정렬 → 근거 |
| LangChain | FastEmbed 임베딩은 실제 사용. **현재 HTTP는 hybrid_search 직접 호출** |
| BGE-M3 | beauty 78,595청크의 1,024차원 별도 프로필 ready. 기본 API 모델은 아직 MiniLM |
| all_products | 이름과 달리 이전 test_items/beauty 180상품 프로필 |

이 표는 새 성능 평가 결과가 아니다. 모델 비교 점수에는 질문 수와 라벨의 한계가 있으므로 [평가 정리](model-comparisons-and-evaluation.md)의 조건을 함께 읽는다.

## 자료 정리 방식

- 원문·평가·스키마·예제 **231개**를 수록했다. 발견 위치/버전은 **277건**이며 같은 내용의 중복 46건은 사본을 합쳤다. 이 수량에 새로 작성한 통합 요약 문서는 포함하지 않는다.
- 현재 파일, Backend의 여러 worktree, 이전 프로젝트 worktree, 로컬 Git 브랜치/ref의 문서 버전, 전달된 프롬프트 원문, 데이터 내보내기 ZIP의 문서/manifest를 조사했다.
- 바이트가 같은 중복본은 한 번 보관하고 발견 위치를 모두 기록했다. 같은 파일명이어도 내용이 다르면 별도로 남겼다.
- 작업 트리에서 삭제된 과거 계약/평가 문서는 Git blob을 읽어 이 폴더에 사본으로 보존했다. 다른 작업 폴더의 삭제 상태를 복원하지 않았다.
- `archive/`에는 원문을 보관한다. 원문 속 상대 링크·서버 주소·“현재”라는 표현은 **작성 당시 맥락**이므로 현재 탐색에는 통합 목차와 전체 목록을 사용한다.
- 원본 데이터/벡터 덤프·모델 가중치·실제 비밀 환경 파일·DB 저장 디렉터리는 문서 묶음에 복사하지 않았다. 대용량 데이터 ZIP은 위치와 manifest만 기록했다.
- 조사 범위는 이 서버에서 접근한 프로젝트와 명시한 Git ref/첨부 자료다. 외부 Drive/팀 채팅/미연결 저장소의 문서나 모든 중간 Git 커밋까지 조사했다는 뜻은 아니다.

문서 종류별 정확한 수량과 조사 경로는 [전체 목록](document-catalog.md)에 있다.

## 앞으로 갱신할 위치

1. 배포 모델·프로필·HTTP 경로를 바꾸면 `current-system.md`와 확인 증거를 갱신한다.
2. 데이터와 run을 바꾸면 `datasets-and-storage.md`에 버전·수량·출처를 기록한다.
3. 청커/모델을 바꾸면 `chunking-and-embeddings.md`에 실제 적용 run과 코드 상태를 구분한다.
4. 새 평가는 `model-comparisons-and-evaluation.md`에 데이터·질문·정답 승인·코드·경로·지연 측정 조건을 함께 기록한다.
5. 새 원문은 전체 목록과 manifest에 추가한다. 과거 결과를 최신 운영 결과로 덮어쓰지 않는다.

팀 작업 규칙의 정본은 기존 [team-git-workflow.md](../team-git-workflow.md)다. 이 정리는 **Backend `feature/rag-documentation-index`의 로컬 문서 변경**이며, 문서 작업으로 서비스·DB·활성 색인·모델을 전환하지 않았다. 커밋·GitHub 푸시·main 병합도 이번 작업에서 수행하지 않았다.
