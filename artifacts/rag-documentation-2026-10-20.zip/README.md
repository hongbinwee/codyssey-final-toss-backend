# Product RAG recommendation quality

기존 5432 PostgreSQL과 상품·리뷰 임베딩을 재사용하는 RAG 서비스입니다.

- **[RAG 통합 문서 목차 — 현재 구성·데이터·청킹·모델 비교·전체 원문](docs/rag/README.md)**
- [구현 내용·Brain 연동 계약·제약](docs/rag-recommendation-quality.md)
- [요청 JSON Schema](contracts/product-rag/v0.3/request.schema.json)
- [실행 설정 예시](deploy/product-rag-runtime.env.example)
- [팀 Git 협업 기준](docs/team-git-workflow.md)
- [작업 정리 PDF · 5쪽](docs/rag/archive/quality/docs/reports/rag-recommendation-quality-summary-2026-10-19.pdf)

현재 배포·활성 색인·모델 상태는 [2026-10-20 실행 증거를 반영한 구성 문서](docs/rag/current-system.md)를 참고합니다.
PDF와 과거 구현 기록의 상태 표시는 작성 당시의 스냅샷입니다.
문서 정리 브랜치의 로컬 저장, 커밋, 원격 공유, main 반영은 별도로 구분합니다.
