# RAG 문서 묶음 — 2026-10-20

시작: docs/rag/README.md
전체 원문 목록: docs/rag/document-catalog.md
출처/중복/해시: docs/rag/source-manifest.json

원문·평가·스키마·예제 231개와 통합 요약을 포함합니다.
문서에서 참조하는 24a1051 기반 Python RAG 소스와 요청 스키마를 읽기용으로 포함했습니다.
이 ZIP 자체가 실행 가능한 전체 서비스 배포 패키지라는 뜻은 아닙니다.

문서 상태 기준은 2026-10-20 14:47 KST의 읽기 전용 실행 증거입니다.
원문 아카이브의 링크·주소·현재라는 표현은 작성 당시 맥락으로 해석합니다.
외부 원본 데이터 ZIP은 원래 서버 경로에 있으며, 이 묶음에는 위치와 메타데이터만 있습니다.
API 키·실제 .env·DB 비밀번호·모델 가중치·원본/벡터 덤프는 포함하지 않습니다.

Git 저장소: hongbinwee/codyssey-final-toss-backend
문서 작업 브랜치: feature/rag-documentation-index
문서 로컬 저장 상태이며 새 커밋/푸시/main 반영을 뜻하지 않습니다.
