"""Product-grounded retrieval service."""
