# PostgreSQL · test_items2 · RAG 운영 인수인계

1. 같은 폴더의 PDF로 전체 내용을 읽으세요. PDF 33쪽, 원본/색인/모델 교체 절차 및 상세 API 계약 포함.
2. 수정 가능한 원문은 handover/rag-db-operations-handover-2026-10-19.md입니다.
3. handover/rag-api-tailscale.postman_collection.json을 Postman에 Import하면 Tailscale 주소로 호출할 수 있습니다.
4. SQL 파일은 파일에 명시된 DB에서 읽기 전용으로 사용합니다. *.schema.sql은 변경 명령을 포함한 참고 DDL이며 운영 DB에 자동 실행하지 않습니다.

핵심 연결:
- PostgreSQL: chancelab-spark.tailbc019f.ts.net:5432
- 원본: toss DB → test_items2 스키마
- 청크·벡터: toss_rag DB → rag 스키마 → evidence_chunks
- API: https://chancelab-spark.tailbc019f.ts.net:8002
- GET /healthz / POST /v1/rag/search / 기본 profile=test_items2

같은 384차원이라도 임베딩 모델을 바꾸면 문서 벡터를 다시 생성해야 합니다. 현재 차원 고정·청커 모델 상수·입력 규약과 완성된 재색인 CLI가 없다는 점을 본문의 모델 교체 장에서 확인하세요.

모델 변경·재색인·색인 전환·복원은 이번 문서 작성에서 실행하지 않았습니다. 인증정보·실제 runtime.env·previous-container.json·모델 가중치·대용량 원본/벡터 데이터 ZIP은 포함하지 않습니다. 대용량 데이터 위치와 SHA-256은 handover/data-archive-locator.json에 있습니다.
