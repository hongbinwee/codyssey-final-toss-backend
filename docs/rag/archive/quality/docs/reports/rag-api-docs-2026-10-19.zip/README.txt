Product RAG API 연동 자료 (2026-10-19)

공유용 PDF: docs/reports/rag-api-guide-2026-10-19.pdf
전체 정본: docs/api/rag-api-guide-2026-10-19.md
Postman Import: docs/api/rag-api.postman_collection.json
요청 파일: docs/api/examples/rag-search.request.json
응답 예시는 설명용 가상 값이며 실제 검색 결과가 아닙니다.

Base URL: https://rag.chanuk.theworkpc.com
GET /healthz
POST /v1/rag/search
기본 프로필: test_items2
